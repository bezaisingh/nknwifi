# nknwifi
Web Portal for the students and staff of Assam University to register for the Campus Wifi credentials.
